DROP TABLE IF EXISTS `user_register`;
CREATE TABLE `user_register` (
  `sno` int NOT NULL AUTO_INCREMENT,
  `name` char(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(40) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`sno`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

INSERT INTO `user_register` (`sno`, `name`, `email`, `phone`, `password`, `img`) VALUES
(1,	'Loki',	'Logeshnr17@gmail.com',	'0987654321',	'12345678',	'uploads/1.png');

