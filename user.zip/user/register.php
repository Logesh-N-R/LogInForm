<?php
$error = [];
if (!isset($_POST['name']) || empty($_POST['name'])) {
    $error['name'] = "Enter Name";
}
if (isset($_POST['email']) && !empty($_POST['email'])) {
    if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
        $error['email'] = "Invalid email format";
    }
} else {
    $error['email'] = "Enter email id";
}
if (isset($_POST['password']) && !empty($_POST['password'])) {
    if (strlen($_POST['password']) < 8) {
        $error['password'] = "Password should be 8 charecters";
    }
} else {
    $error['password'] = "Enter Password";
}

if (isset($_POST['phone']) && !empty($_POST['phone'])) {
    if (strlen($_POST['phone']) < 8) {
        $error['phone'] = "Phone should be atlease 8 charecters";
    }
} else {
    $error['phone'] = "Enter Phone number";
}
if (empty($error)) {
    include "dbConnect.php";
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    // $password = $_POST['password'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); 



    $sql = "SELECT email,password FROM user_register";
    // $sql = "SELECT id, firstname, lastname FROM MyGuests";
    $result = mysqli_query($conn,$sql);
    // $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        // output data of each row
        while ($row = $result->fetch_assoc()) {
            // echo "name: " . $row["name"]."- password ". $row["password"]. "<br>";
            $emailRegistered[] = $row["email"];
        }
        if (!in_array($email, $emailRegistered)) {

            $sql = "INSERT INTO user_register (name, email, phone, password)
            VALUES ('$name', '$email', '$phone', '$password')";
            if ($conn->query($sql) === TRUE) {
                $dbVal = "New record created successfully";
            } else {
                $dbVal = "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            $error['email'] = "User email registered already";
            $message = [
                "status" => "failed",
                "data" => $error
            ];
            die(json_encode($message));
        }
    }

    $conn->close();

    $message = [
        "status" => "success",
        // "data" => $dbVal
    ];
    print_r(json_encode($message));
} else {
    $message = [
        "status" => "failed",
        "data" => $error
    ];
    print_r(json_encode($message));
}
