<?php
session_start(); 

$error = [];
if (isset($_POST['email']) && empty($_POST['email'])) {
    $error['email'] = "Enter User Name";
}
if (isset($_POST['password']) && empty($_POST['password'])) {
    $error['password'] = "Enter Password";
}

if (empty($error)) {
    include "dbConnect.php";
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "SELECT email, password FROM user_register";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $registeredEmail[] = $row["email"];
        }
    }
    if (in_array($email, $registeredEmail)) {
        $sql = "SELECT sno,password,name FROM user_register WHERE email = '$email'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
                $row=$result->fetch_assoc();
                $dbPassword = $row["password"];
                if (password_verify($password, $dbPassword)) {
                // if($password == $dbPassword){
                    $_SESSION['name'] = $row["name"];
                    $_SESSION['image'] = "";
                    $_SESSION['id'] = $row["sno"];
                    $message = [
                        "status" => "success",
                        // "data" => $dbVal
                    ];
                    print_r(json_encode($message));
                }else{
                    $message = [
                        "status" => "failed",
                        "data" => ["response"=>"Incorrect Password"]
                    ];
                    print_r(json_encode($message));
                }
            // }
        }else{
            $message = [
                "status" => "failed",
                "data" => ["response"=>"no user registed on this user name"]
            ];
            print_r(json_encode($message));

        }
    }else{
        $message = [
            "status" => "failed",
            "data" => ["response"=>"no user registed on this user name"]
        ];
        print_r(json_encode($message));
    }

    $conn->close();

    
} else {
    $message = [
        "status" => "failed",
        "data" => $error
    ];
    print_r(json_encode($message));
}
